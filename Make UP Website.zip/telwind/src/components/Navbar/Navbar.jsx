import React, { useState } from 'react';
import { FaSearch, FaShoppingCart, FaUser, FaBars } from 'react-icons/fa';
import ProductCard from '../Products/ProductCard';
import coverImage from '../../assets/cover.png';
import logoImage from '../../assets/logoo.png';
import lipImage from '../../assets/lip.jpg';
import prodImage from '../../assets/prod.jpg';
import olpImage from '../../assets/olp.jpg';
import blusherImage from '../../assets/blasher.jpg';
import brown from '../../assets/brown.png';
import foundation from '../../assets/foundation.jpg';
import eye from '../../assets/eye.jpg';
import essence from '../../assets/essence.jpg';
import RegistrationForm from '../Register/RegistrationForm';
import clavier from '../../assets/clavier.jpg';
import Br from '../../assets/Br.jpg';
import May from '../../assets/May.jpg';
import Gel from '../../assets/Gel.jpg';
import Footer from '../footer/Footer';
import Nail from '../../assets/Nail.jpg';
import Herla from '../../assets/Herla.jpg';
import wella from '../../assets/wella.jpg';
import Acids from '../../assets/Acids.jpg';
import rouge from '../../assets/rouge.jpg';
import bouder from '../../assets/bouder.jpg';
const pages = ['Eyes', 'Eyebrows', 'Lips', 'Face', 'Nails', 'Hair', 'Care', 'Sets', 'House', 'Brands'];
const products = [
  { image: lipImage, title: 'Lip Balm', price: '55$' ,description:'lip balm is available on all shades in our sites'},
  { image: prodImage, title: 'Paw Patrol', price: '45$' ,description:'lip balm is available on all shades in our sites'},
  { image: olpImage, title: 'Mascara', price: '35$' ,description:'lip balm is available on all shades in our sites'},
  { image: blusherImage, title: 'Blusher', price: '25$',description:'lip balm is available on all shades in our sites' },
  { image: brown, title: 'Browny', price: '15$',description:'lip balm is available on all shades in our sites' },
  { image: foundation, title: 'Foundation', price: '50$' ,description:'lip balm is available on all shades in our sites'},
  { image: eye, title: 'Eye Crown', price: '20$',description:'lip balm is available on all shades in our sites' },
  { image: essence, title: 'Essence', price: '30$' ,description:'lip balm is available on all shades in our sites'},

];
const Recomended = [
  { image: clavier, title: 'clavier', price: '30$',description:'lip balm is available on all shades in our sites' },
  { image: Br, title: 'Brusher', price: '55$' ,description:'lip balm is available on all shades in our sites'},
  { image: May, title: 'Maybline', price: '88$' ,description:'lip balm is available on all shades in our sites'},
  { image: Gel, title: 'Men Gel', price: '60$',description:'lip balm is available on all shades in our sites' },
];
const Buy = [
  { image: Nail, title: 'Nail', price: '30$',description:'lip balm is available on all shades in our sites' },
  { image: Herla, title: 'Herla', price: '55$',description:'lip balm is available on all shades in our sites' },
  { image: wella, title: 'wella', price: '88$' ,description:'lip balm is available on all shades in our sites'},
  { image: Acids, title: 'Acids', price: '60$',description:'lip balm is available on all shades in our sites' },
];

function ResponsiveAppBar() {
  const [searchExpanded, setSearchExpanded] = useState(false);
  const [navExpanded, setNavExpanded] = useState(false);

  const toggleSearch = () => {
    setSearchExpanded(!searchExpanded);
  };

  const toggleNav = () => {
    setNavExpanded(!navExpanded);
  };

  return (
    <>
      <div className="bg-transparent text-white py-2 flex justify-between items-center px-4">
        <div className="relative flex-grow max-w-xs mx-auto">
          <input
            type="text"
            placeholder="Search"
            className={`w-full border border-gray-300 rounded py-2 px-4 ${searchExpanded ? 'block' : 'hidden'}`}
          />
          <button className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-500" onClick={toggleSearch}>
            <FaSearch />
          </button>
        </div>
        <div className="flex items-center gap-4">
          <a href="#" className="hover:text-gray-300">
            <FaUser />
          </a>
          <a href="#" className="hover:text-gray-300">
            <FaShoppingCart />
          </a>
        </div>
      </div>
      <nav className="bg-black text-white py-4">
        <div className="container mx-auto flex justify-between items-center">
          <a href="/">
            <img src={logoImage} alt="Make Up" className="h-10 w-100" />
          </a>
          <div className="hidden md:flex space-x-8">
            {pages.map((page) => (
              <a
                key={page}
                href={`#${page.toLowerCase()}`}
                className="text-white hover:bg-pink-500 px-3 py-2 rounded-md text-lg"
              >
                {page}
              </a>
            ))}
          </div>
          <div className="md:hidden flex items-center">
            <button className="text-white focus:outline-none" onClick={toggleNav}>
              <FaBars />
            </button>
          </div>
        </div>
      </nav>
      {navExpanded && (
        <div className="md:hidden bg-black text-white py-4">
          <div className="container mx-auto flex flex-col space-y-5 text-5xl">
            {pages.map((page) => (
              <a
                key={page}
                href={`#${page.toLowerCase()}`}
                className="text-white hover:bg-pink-500 px-3 py-2 rounded-md text-lg"
                onClick={toggleNav}
              >
                {page}
              </a>
            ))}
          </div>
        </div>
      )}
      <img src={coverImage} alt="Cover" className="w-full mt-2" />
      <div className="container mx-auto mt-4">
        <h2 className="text-center text-4xl mb-4  hover:bg-pink-100">NEW PRODUCTS</h2>
        <div className="flex flex-wrap justify-center">
          {products.map((product, index) => (
            <ProductCard
              key={index}
              image={product.image}
              title={product.title}
              price={product.price}
              description={product.description}
              onAddToCart={() => console.log(`${product.title} added to cart`)}
            />
          ))}
        </div>
      </div>
      <div className="container mx-auto mt-4">
        <h2 className="text-center text-4xl mb-4  hover:bg-pink-100">RECOMMENDED COSMETICS AND ACCESSORIES IN THE STORE</h2>
        <div className="flex flex-wrap justify-center">
          {Recomended.map((product, index) => (
            <ProductCard
              key={index}
              image={product.image}
              title={product.title}
              price={product.price}
              description={product.description}
              onAddToCart={() => console.log(`${product.title} added to cart`)}
            />
          ))}
        </div>
      </div>
      <div className="container mx-auto mt-4">
        <h2 className="text-center text-4xl mb-4 hover:bg-pink-100">BUY NOW AT A BARGAIN PRICE
</h2>
        <div className="flex flex-wrap justify-center">
          {Buy.map((product, index) => (
            <ProductCard
              key={index}
              image={product.image}
              title={product.title}
              price={product.price}
              description={product.description}
              onAddToCart={() => console.log(`${product.title} added to cart`)}
            />
          ))}
        </div>
      </div>
      <div className="container mx-auto mt-4 mb-4">
        <div className="flex justify-between flex-wrap">
          <div className="flex-1 min-w-300 mr-2">
            <RegistrationForm />
          </div>
          <div className="flex-1 min-w-300 bg-pink-100 p-4 rounded">
            <h5 className="font-bold mb-2">GET POINTS AND BUY CHEAPER!</h5>
            <p className="mb-2">
              Registered users can join our loyalty program, a reward system based on points. You can earn points and turn them into a shopping discount. Have a look at the list of activities that earn you points.
            </p>
            <button className="bg-pink-500 text-white py-2 px-4 rounded hover:bg-pink-600">
              Details
            </button>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}

export default ResponsiveAppBar;
