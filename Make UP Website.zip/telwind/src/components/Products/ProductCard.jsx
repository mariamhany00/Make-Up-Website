import React from 'react';
import { FaShoppingCart } from 'react-icons/fa';

const ProductCard = ({ image, title, price,description, onAddToCart }) => {
  return (
    <div className="max-w-sm mx-auto rounded overflow-hidden shadow-lg my-4 transition-transform transform hover:scale-105 hover:shadow-2xl">
      <img className="w-full h-64 object-cover" src={image} alt={title} />
      <div className="px-6 py-4">
        <div className="font-bold  text-pink-500 text-xl mb-2">{title}</div>
        <p className="text-gray-700 text-base">{price}</p>
        <p className="text-gray-1000 text-base">{description}</p>
      </div>
      <div className="px-6 py-4">
        <button
          onClick={onAddToCart}
          className="bg-gray-800 hover:bg-pink-500 text-white font-bold py-2 px-4 rounded inline-flex items-center transition-colors"
        >
          <FaShoppingCart className="mr-2" />
          Add to Cart
        </button>
      </div>
    </div>
  );
};

export default ProductCard;
