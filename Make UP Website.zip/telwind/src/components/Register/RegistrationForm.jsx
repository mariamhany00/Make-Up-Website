import React from 'react';

const RegistrationForm = () => {
  return (
    <div className="container mx-auto mr-10 px-10">
      <h5 className="text-2xl font-semibold mb-4">Register</h5>
      <form className="flex flex-col gap-4 max-w-sm">
        <div className="flex flex-col">
          <label htmlFor="firstName" className="mb-1 text-gray-700">First Name</label>
          <input id="firstName" type="text" className=" border border-pink-700 rounded p-2" />
        </div>
        <div className="flex flex-col">
          <label htmlFor="lastName" className="mb-1 text-gray-700">Last Name</label>
          <input id="lastName" type="text" className="border border-pink-700 rounded p-2" />
        </div>
        <div className="flex flex-col">
          <label htmlFor="email" className="mb-1 text-gray-pink">Email</label>
          <input id="email" type="email" className="border border-pink-700 rounded p-2" />
        </div>
        <div className="flex flex-col">
          <label htmlFor="password" className="mb-1 text-gray-700">Password</label>
          <input id="password" type="password" className="border border-pink-700 rounded p-2" />
        </div>
        <button type="submit" className="bg-pink-500 text-white py-2 rounded mt-50 hover:bg-pink-500">
          Sign Up
        </button>
      </form>
    </div>
  );
};

export default RegistrationForm;
