import React from 'react';

const Footer = () => {
  return (
    <div className="bg-black text-white py-3 mt-4">
      <div className="container mx-auto px-4 flex flex-wrap justify-between items-center">
        <div className="flex items-center">
          <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-white hover:text-gray-400 mx-2">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
              <path d="M9 8H7V6h2V4a3 3 0 013-3h2v2h-2a1 1 0 00-1 1v2h3v2h-3v8H9z" />
            </svg>
          </a>
          <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-white hover:text-gray-400 mx-2">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
              <path d="M20.83 7.16a8.44 8.44 0 01-2.36.65 4.13 4.13 0 001.82-2.27 8.23 8.23 0 01-2.6 1 4.17 4.17 0 00-7.16 3.8A11.79 11.79 0 013 5.61a4.14 4.14 0 001.28 5.56 4.06 4.06 0 01-1.89-.52v.06a4.17 4.17 0 003.34 4.08 4.2 4.2 0 01-1.88.07 4.17 4.17 0 003.89 2.88A8.36 8.36 0 013 18.29a11.75 11.75 0 006.29 1.84c7.55 0 11.68-6.15 11.68-11.49l-.01-.52a8.36 8.36 0 002.1-2.13z" />
            </svg>
          </a>
          <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-white hover:text-gray-400 mx-2">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2.2c3.02 0 3.38.01 4.57.07 1.17.06 1.97.25 2.45.42.6.23 1.03.51 1.48.95.44.45.72.88.95 1.48.17.48.36 1.28.42 2.45.06 1.19.07 1.55.07 4.57s-.01 3.38-.07 4.57c-.06 1.17-.25 1.97-.42 2.45-.23.6-.51 1.03-.95 1.48-.45.44-.88.72-1.48.95-.48.17-1.28.36-2.45.42-1.19.06-1.55.07-4.57.07s-3.38-.01-4.57-.07c-1.17-.06-1.97-.25-2.45-.42-.6-.23-1.03-.51-1.48-.95-.44-.45-.72-.88-.95-1.48-.17-.48-.36-1.28-.42-2.45-.06-1.19-.07-1.55-.07-4.57s.01-3.38.07-4.57c.06-1.17.25-1.97.42-2.45.23-.6.51-1.03.95-1.48.45-.44.88-.72 1.48-.95.48-.17 1.28-.36 2.45-.42 1.19-.06 1.55-.07 4.57-.07zM12 0C8.8 0 8.4.01 7.2.07 6 .12 5.14.31 4.4.57c-.76.27-1.42.61-2.07 1.25C1.36 2.5 1.02 3.16.75 3.92.5 4.66.31 5.5.25 6.8.19 8 0 8.4 0 12c0 3.6.01 4 .07 5.2.06 1.3.25 2.14.5 2.88.27.76.61 1.42 1.25 2.07.64.64 1.3.98 2.07 1.25.74.26 1.58.45 2.88.5 1.2.06 1.6.07 5.2.07s4-.01 5.2-.07c1.3-.06 2.14-.25 2.88-.5.76-.27 1.42-.61 2.07-1.25.64-.64.98-1.3 1.25-2.07.26-.74.45-1.58.5-2.88.06-1.2.07-1.6.07-5.2s-.01-4-.07-5.2c-.06-1.3-.25-2.14-.5-2.88-.27-.76-.61-1.42-1.25-2.07-.64-.64-1.3-.98-2.07-1.25-.74-.26-1.58-.45-2.88-.5-1.2-.06-1.6-.07-5.2-.07z" />
              <path d="M12 5.8a6.2 6.2 0 100 12.4 6.2 6.2 0 000-12.4zm0 10.2a4 4 0 110-8 4 4 0 010 8zM18.4 4.5a1.4 1.4 0 11-2.8 0 1.4 1.4 0 012.8 0z" />
            </svg>
          </a>
        </div>
        <div className="text-center">
          <p className="text-base">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 inline-block mr-2" fill="currentColor" viewBox="0 0 24 24">
              <path d="M6.62 10.79a15.07 15.07 0 006.59 6.59l2.2-2.2a1 1 0 01.9-.27c1.05.27 2.2.42 3.4.42.55 0 1 .45 1 1v3.39c0 .55-.45 1-1 1C11.07 22 2 12.93 2 3.38 2 2.83 2.45 2.38 3 2.38H6.39c.55 0 1 .45 1 1 0 1.2.15 2.35.42 3.4.07.37 0 .76-.27 1.03L6.62 10.8z" />
            </svg>
            +1 (234) 567-890
          </p>
        </div>
        <div className="text-center w-full mt-4 lg:mt-0 lg:w-auto lg:flex-grow-0 lg:flex-shrink">
          <p className="text-base">&copy; {new Date().getFullYear()} Lady Make UP. All rights reserved.</p>
        </div>
      </div>
    </div>
  );
};

export default Footer;
